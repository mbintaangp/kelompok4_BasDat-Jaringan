﻿Imports System.Data.SqlClient

Public Class Form1
    Private connectionString As String = "Data Source=nama_server;Initial Catalog=nama_database;User ID=nama_pengguna;Password=sandi"
    Private connection As SqlConnection
    Private command As SqlCommand
    Private adapter As SqlDataAdapter
    Private dataTable As DataTable

    Private Sub OpenConnection()
        connection = New SqlConnection(connectionString)
        connection.Open()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim ellipseRadius As New Drawing2D.GraphicsPath
        ellipseRadius.StartFigure()
        ellipseRadius.AddArc(New Rectangle(0, 0, 20, 20), 180, 90)
        ellipseRadius.AddLine(20, 0, BtPasien.Width - 20, 0)
        ellipseRadius.AddArc(New Rectangle(BtPasien.Width - 20, 0, 20, 20), -90, 90)
        ellipseRadius.AddLine(BtPasien.Width, 20, BtPasien.Width, BtPasien.Height - 20)
        ellipseRadius.AddArc(New Rectangle(BtPasien.Width - 20, BtPasien.Height - 20, 20, 20), 0, 90)
        ellipseRadius.AddLine(BtPasien.Width - 20, BtPasien.Height, 20, BtPasien.Height)
        ellipseRadius.AddArc(New Rectangle(0, BtPasien.Height - 20, 20, 20), 90, 90)
        ellipseRadius.CloseFigure()
        BtPasien.Region = New Region(ellipseRadius)
    End Sub

    Private Sub BtPasien_Click(sender As Object, e As EventArgs) Handles BtPasien.Click
        dataTable = New DataTable()
        adapter = New SqlDataAdapter("SELECT * FROM Pasien", connection)
        adapter.Fill(dataTable)

        DataGridView1.DataSource = dataTable
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        dataTable = New DataTable()
        adapter = New SqlDataAdapter("SELECT * FROM Pemeriksaan", connection)
        adapter.Fill(dataTable)

        DataGridView1.DataSource = dataTable
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        dataTable = New DataTable()
        adapter = New SqlDataAdapter("SELECT * FROM Resep", connection)
        adapter.Fill(dataTable)

        DataGridView1.DataSource = dataTable
    End Sub
End Class
